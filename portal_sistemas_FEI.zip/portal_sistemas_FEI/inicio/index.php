<html lang="en" style="filter: invert(0);">
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Astro description">
        <meta name="viewport" content="width=device-width">
        <link rel="icon" type="image/x-icon" href="favicon.ico">
        <meta name="generator" content="Astro v4.4.1"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <title>Sistemas FEI</title>
        <style>
            img[data-astro-cid-dohjnao5]
            {
                max-width:300px;
                max-height:100px;
                object-fit:cover
            }
            .card[data-astro-cid-dohjnao5]
            {
                place-self:center;
                max-width:300px;
                box-shadow:0 10px 10px gray;
                border:none;
                border-radius:10px
            }
            .card-body[data-astro-cid-dohjnao5]
            {
                background-color:#18529d;
                border-radius:0 0 10px 10px;
                max-height:300px
            }
            h5[data-astro-cid-dohjnao5]
            {
                font-size:clamp(5px,4vw,15px)
            }
            .logo-fei[data-astro-cid-ymhdp2rl]
            {
                width:80px;height:80px
            }
            .logo-uv[data-astro-cid-ymhdp2rl]
            {
                width:100px;height:80px
            }
            nav[data-astro-cid-ymhdp2rl]
            {
                box-shadow:#00000073 0 10px 20px -20px
            }
            @media (max-width:600px)
            {
                .logo-fei[data-astro-cid-ymhdp2rl]
                {
                    width:50px;height:50px
                }
                .logo-uv[data-astro-cid-ymhdp2rl]
                {
                    display:none
                }
            }
            .contenedor[data-astro-cid-bji27afj]
            {
                display:grid;
                margin:2rem;
                grid-template-columns:1fr 1fr 1fr;
                grid-auto-flow:dense;
                gap:2rem
            }
            @media (max-width:1000px)
            {
                .contenedor[data-astro-cid-bji27afj]
                {
                    grid-template-columns:repeat(auto-fill,minmax(min(100%,20rem),1fr))
                }
            }
            body
            {
                background-color: #efecec;
                font-family:Gill Sans,Gill Sans MT,Calibri,Trebuchet MS,sans-serif
            }
        </style>
    </head> 
    <body>  
        <nav class="navbar bg-body-tertiary " data-astro-cid-ymhdp2rl=""> 
            <div class="container-fluid d-flex justify-content-around" data-astro-cid-ymhdp2rl=""> 
                <a href="http://www.uv.mx/fei" data-astro-cid-ymhdp2rl="">
                    <img src="_astro/logoFEI.CKAzzJnF_ZyfpCW.webp" class="logo-fei" alt="Logo FEI" loading="eager" data-astro-cid-ymhdp2rl="" width="567" height="662" decoding="async" style="filter: invert(0);">
                </a> 
                <h1 class="text-success" data-astro-cid-ymhdp2rl="">Portal de sistemas FEI</h1>
                <a href="http://www.uv.mx" data-astro-cid-ymhdp2rl="">
                    <img src="_astro/logoUV.gPBiyME4_N2yL.webp" class="logo-uv" alt="Logo Universidad Veracruzana" loading="eager" data-astro-cid-ymhdp2rl="" width="1363" height="1182" decoding="async" style="filter: invert(0);">
                </a> 
            </div> 
        </nav>  
        <div class="contenedor " data-astro-cid-bji27afj="">  
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/aulaFEI.Bfi36lLc_Z2aGaTO.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="4176" height="2784" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Sistema de Gestion de Claves de Aulas</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/aulaclase/" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a>
                    </div> 
                </div> 
            </div>  
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/edificioFEI.C5q6RF30_Z1jodpw.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="1024" height="768" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">MOODLE FEI</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/moodle/" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div>  
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/lista.B6Wjs7Qp_cSdLO.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="2173" height="1739" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Sistema de Control de Asistencias</h5>
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/controlasistencia/" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div>  
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/PEDPA.CaZEdBX2_Zm1Ox5.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="474" height="450" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Sistema de Estimulos al Desempeño del Personal Academico 2021-2023</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/pedpa2123/" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div> 
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/sistemaAvisosFEI.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="474" height="450" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Sistema de Avisos</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/bannersfei/" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div>
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/formularioForms.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="474" height="450" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Formulario de Registro de Eventos</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://forms.office.com/pages/responsepage.aspx?id=UXaQPMbYpkyopGokJDDmU-mq0IRCUa9Ei8mq08oDurxUMDJJQkQ2S1RTRU4zRTQ0SVpINENHQTNWRi4u&route=shorturl" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div>   
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/DashboardDesign.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="474" height="450" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Dashboard PBR</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/dashboardfei/login" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div>   
            <div class="card mx-2" style="width: 18rem;" data-astro-cid-dohjnao5=""> 
                <img src="_astro/registroHorario.webp" class="card-img-top" loading="eager" alt="foto" data-astro-cid-dohjnao5="" width="474" height="450" decoding="async" style="filter: invert(0);"> 
                <div class="card-body" data-astro-cid-dohjnao5=""> 
                    <h5 class="card-title text-light" data-astro-cid-dohjnao5="">Registro de Horarios de Tutoría</h5> 
                    <div class="text-end" data-astro-cid-dohjnao5=""> 
                        <a href="https://sistemasfei.uv.mx/agendatutorias/" class="btn btn-success text-end" data-astro-cid-dohjnao5="">
                            Entrar
                        </a> 
                    </div> 
                </div> 
            </div>      
        </div>    
    </body>
</html>
